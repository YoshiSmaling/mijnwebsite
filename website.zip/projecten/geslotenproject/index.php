<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>

    <link href="style.css" rel="stylesheet" type="text/css">

</head>
<body>


<img src="../../img/construction.jpg" class="constructie">


</body>
</html>