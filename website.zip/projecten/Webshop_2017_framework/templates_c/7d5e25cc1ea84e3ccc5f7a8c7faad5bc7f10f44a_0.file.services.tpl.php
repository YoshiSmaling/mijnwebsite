<?php
/* Smarty version 3.1.29, created on 2016-04-04 23:11:14
  from "C:\wamp\www\Smarty_voorbeeld\templates\services.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5702d872e457f1_37584104',
  'file_dependency' => 
  array (
    '7d5e25cc1ea84e3ccc5f7a8c7faad5bc7f10f44a' => 
    array (
      0 => 'C:\\wamp\\www\\Smarty_voorbeeld\\templates\\services.tpl',
      1 => 1459804013,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5702d872e457f1_37584104 ($_smarty_tpl) {
?>
<div id="services" class="container-fluid text-center">
  <h2>SERVICES</h2>
  <h4>What we offer</h4>
  <br>
  <div class="row">
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-off"></span>
      <h4>gebruikte hardware</h4>
      <p>Lorem ipsum dolor sit amet..</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-heart"></span>
      <h4>reparaties</h4>
      <p>Lorem ipsum dolor sit amet..</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-lock"></span>
      <h4>installaties</h4>
      <p>Lorem ipsum dolor sit amet..</p>
    </div>
    </div>
    <br><br>
  <div class="row">
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-leaf"></span>
      <h4>netwerken</h4>
      <p>Lorem ipsum dolor sit amet..</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-certificate"></span>
      <h4>stage</h4>
      <p>Lorem ipsum dolor sit amet..</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-wrench"></span>
      <h4>projecten</h4>
      <p>Lorem ipsum dolor sit amet..</p>
    </div>
  </div>
</div>
<?php }
}
