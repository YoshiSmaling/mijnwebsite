<?php
/* Smarty version 3.1.29, created on 2017-01-08 21:11:40
  from "C:\wamp64\www\Smarty_voorbeeld\templates\services.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5872ab0cc18248_51325409',
  'file_dependency' => 
  array (
    'ad25e5f2a821ca22aa5dfd94fb593c52871762c9' => 
    array (
      0 => 'C:\\wamp64\\www\\Smarty_voorbeeld\\templates\\services.tpl',
      1 => 1459804013,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5872ab0cc18248_51325409 ($_smarty_tpl) {
?>
<div id="services" class="container-fluid text-center">
  <h2>SERVICES</h2>
  <h4>What we offer</h4>
  <br>
  <div class="row">
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-off"></span>
      <h4>gebruikte hardware</h4>
      <p>Lorem ipsum dolor sit amet..</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-heart"></span>
      <h4>reparaties</h4>
      <p>Lorem ipsum dolor sit amet..</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-lock"></span>
      <h4>installaties</h4>
      <p>Lorem ipsum dolor sit amet..</p>
    </div>
    </div>
    <br><br>
  <div class="row">
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-leaf"></span>
      <h4>netwerken</h4>
      <p>Lorem ipsum dolor sit amet..</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-certificate"></span>
      <h4>stage</h4>
      <p>Lorem ipsum dolor sit amet..</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-wrench"></span>
      <h4>projecten</h4>
      <p>Lorem ipsum dolor sit amet..</p>
    </div>
  </div>
</div>
<?php }
}
