<?php
/* Smarty version 3.1.29, created on 2017-01-08 21:11:40
  from "C:\wamp64\www\Smarty_voorbeeld\templates\banner.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5872ab0c647642_29984809',
  'file_dependency' => 
  array (
    'ca0157faf95c89595d9b1928fcb1fed9babbd732' => 
    array (
      0 => 'C:\\wamp64\\www\\Smarty_voorbeeld\\templates\\banner.tpl',
      1 => 1459803892,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5872ab0c647642_29984809 ($_smarty_tpl) {
?>
<div class="jumbotron">
  <h1>Zadkine</h1> 
  <p>We specialize in blablabla</p>
  <form class="form-inline">
    <input type="email" class="form-control" size="50" placeholder="Email Address">
    <button type="button" class="btn btn-danger">Subscribe</button>
  </form>
</div><?php }
}
