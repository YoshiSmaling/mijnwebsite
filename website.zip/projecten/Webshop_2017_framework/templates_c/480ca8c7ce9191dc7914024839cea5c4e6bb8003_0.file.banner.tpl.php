<?php
/* Smarty version 3.1.29, created on 2017-01-09 20:54:30
  from "C:\wamp64\www\Webshop_2017_framework\templates\banner.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5873f88689a994_04782883',
  'file_dependency' => 
  array (
    '480ca8c7ce9191dc7914024839cea5c4e6bb8003' => 
    array (
      0 => 'C:\\wamp64\\www\\Webshop_2017_framework\\templates\\banner.tpl',
      1 => 1459803892,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5873f88689a994_04782883 ($_smarty_tpl) {
?>
<div class="jumbotron">
  <h1>Zadkine</h1> 
  <p>We specialize in blablabla</p>
  <form class="form-inline">
    <input type="email" class="form-control" size="50" placeholder="Email Address">
    <button type="button" class="btn btn-danger">Subscribe</button>
  </form>
</div><?php }
}
