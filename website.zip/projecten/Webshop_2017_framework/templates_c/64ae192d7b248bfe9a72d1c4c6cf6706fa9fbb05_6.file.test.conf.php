<?php /* Smarty version 3.1.29, created on 2016-03-23 23:13:57
         compiled from "C:\wamp\www\Smarty_startup\configs\test.conf" */ ?>
<?php
/* Smarty version 3.1.29, created on 2016-03-23 23:13:57
  from "C:\wamp\www\Smarty_startup\configs\test.conf" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_56f31525930618_99025193',
  'file_dependency' => 
  array (
    '64ae192d7b248bfe9a72d1c4c6cf6706fa9fbb05' => 
    array (
      0 => 'C:\\wamp\\www\\Smarty_startup\\configs\\test.conf',
      1 => 1458771231,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_56f31525930618_99025193 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'setup' => 
    array (
      'vars' => 
      array (
        'bold' => true,
      ),
    ),
  ),
  'vars' => 
  array (
    'title' => 'Welcome to Smarty!',
    'cutoff_size' => 40,
  ),
));
}
}
