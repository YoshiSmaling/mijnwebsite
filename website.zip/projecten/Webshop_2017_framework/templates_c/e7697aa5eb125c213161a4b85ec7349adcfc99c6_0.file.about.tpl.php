<?php
/* Smarty version 3.1.29, created on 2016-04-04 23:06:05
  from "C:\wamp\www\Smarty_voorbeeld\templates\about.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5702d73ddb6c02_92043669',
  'file_dependency' => 
  array (
    'e7697aa5eb125c213161a4b85ec7349adcfc99c6' => 
    array (
      0 => 'C:\\wamp\\www\\Smarty_voorbeeld\\templates\\about.tpl',
      1 => 1459803928,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5702d73ddb6c02_92043669 ($_smarty_tpl) {
?>
<div id="about" class="container-fluid">
  <div class="row">
    <div class="col-sm-8">
      <h2>About Company Page</h2>
      <h4>Lorem ipsum..</h4> 
      <p>Lorem ipsum..</p>
      <button class="btn btn-default btn-lg">Get in Touch</button>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-signal logo"></span>
    </div>
  </div>
</div><?php }
}
