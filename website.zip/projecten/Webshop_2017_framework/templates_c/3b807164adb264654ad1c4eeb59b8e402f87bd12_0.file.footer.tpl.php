<?php
/* Smarty version 3.1.29, created on 2016-03-23 23:27:17
  from "C:\wamp\www\Smarty_startup\footer.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_56f318457af3f9_87414889',
  'file_dependency' => 
  array (
    '3b807164adb264654ad1c4eeb59b8e402f87bd12' => 
    array (
      0 => 'C:\\wamp\\www\\Smarty_startup\\footer.tpl',
      1 => 1458772034,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_56f318457af3f9_87414889 ($_smarty_tpl) {
?>
</body>
</html>
<?php }
}
