<?php
/* Smarty version 3.1.29, created on 2016-03-23 23:27:17
  from "C:\wamp\www\Smarty_startup\header.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_56f318457724f2_61403432',
  'file_dependency' => 
  array (
    '9745819a076bde66700d48883ee89f28ce46f67d' => 
    array (
      0 => 'C:\\wamp\\www\\Smarty_startup\\header.tpl',
      1 => 1458772013,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_56f318457724f2_61403432 ($_smarty_tpl) {
?>
<html>
<head>
<title><?php echo (($tmp = @$_smarty_tpl->tpl_vars['title']->value)===null||$tmp==='' ? "no title" : $tmp);?>
</title>
</head>
<body>
<?php }
}
