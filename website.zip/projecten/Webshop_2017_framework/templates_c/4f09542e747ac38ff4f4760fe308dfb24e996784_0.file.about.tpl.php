<?php
/* Smarty version 3.1.29, created on 2017-02-21 13:55:16
  from "C:\wamp\www\Webshop_2017_framework\templates\about.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_58ac38b4b8d7e5_94108100',
  'file_dependency' => 
  array (
    '4f09542e747ac38ff4f4760fe308dfb24e996784' => 
    array (
      0 => 'C:\\wamp\\www\\Webshop_2017_framework\\templates\\about.tpl',
      1 => 1459803928,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58ac38b4b8d7e5_94108100 ($_smarty_tpl) {
?>
<div id="about" class="container-fluid">
  <div class="row">
    <div class="col-sm-8">
      <h2>About Company Page</h2>
      <h4>Lorem ipsum..</h4> 
      <p>Lorem ipsum..</p>
      <button class="btn btn-default btn-lg">Get in Touch</button>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-signal logo"></span>
    </div>
  </div>
</div><?php }
}
