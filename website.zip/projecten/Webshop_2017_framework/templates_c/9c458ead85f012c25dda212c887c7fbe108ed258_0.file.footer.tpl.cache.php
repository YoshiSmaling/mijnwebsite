<?php
/* Smarty version 3.1.29, created on 2016-03-23 23:13:58
  from "C:\wamp\www\Smarty_startup\templates\footer.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_56f315264a4521_50741397',
  'file_dependency' => 
  array (
    '9c458ead85f012c25dda212c887c7fbe108ed258' => 
    array (
      0 => 'C:\\wamp\\www\\Smarty_startup\\templates\\footer.tpl',
      1 => 1458770843,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_56f315264a4521_50741397 ($_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '1590956f315264a4528_95642861';
?>
</BODY>
</HTML>
<?php }
}
