<?php
/* Smarty version 3.1.29, created on 2017-01-09 20:54:30
  from "C:\wamp64\www\Webshop_2017_framework\templates\about.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5873f886a274d0_28396519',
  'file_dependency' => 
  array (
    'e2d2445c4b755e2bad2794fb7be5aefa039d8edc' => 
    array (
      0 => 'C:\\wamp64\\www\\Webshop_2017_framework\\templates\\about.tpl',
      1 => 1459803928,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5873f886a274d0_28396519 ($_smarty_tpl) {
?>
<div id="about" class="container-fluid">
  <div class="row">
    <div class="col-sm-8">
      <h2>About Company Page</h2>
      <h4>Lorem ipsum..</h4> 
      <p>Lorem ipsum..</p>
      <button class="btn btn-default btn-lg">Get in Touch</button>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-signal logo"></span>
    </div>
  </div>
</div><?php }
}
