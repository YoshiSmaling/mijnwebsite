<?php
/* Smarty version 3.1.29, created on 2016-03-23 23:13:58
  from "C:\wamp\www\Smarty_startup\templates\header.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => true,
  'version' => '3.1.29',
  'unifunc' => 'content_56f3152614f312_65350761',
  'file_dependency' => 
  array (
    '8ceb1bec5d06b899e2b4fad6fdbe656fdeb7af8b' => 
    array (
      0 => 'C:\\wamp\\www\\Smarty_startup\\templates\\header.tpl',
      1 => 1458770843,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_56f3152614f312_65350761 ($_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '873256f31525a24219_31859131';
?>
<HTML>
<HEAD>
<TITLE><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - <?php echo '/*%%SmartyNocache:873256f31525a24219_31859131%%*/<?php echo $_smarty_tpl->tpl_vars[\'Name\']->value;?>
/*/%%SmartyNocache:873256f31525a24219_31859131%%*/';?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<?php }
}
