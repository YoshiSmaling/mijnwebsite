<?php
/* Smarty version 3.1.29, created on 2016-04-04 23:04:56
  from "C:\wamp\www\Smarty_voorbeeld\templates\banner.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5702d6f8472664_43486143',
  'file_dependency' => 
  array (
    '64751f4c4c5ac7cc5d027dc7fa7afe362213b2e1' => 
    array (
      0 => 'C:\\wamp\\www\\Smarty_voorbeeld\\templates\\banner.tpl',
      1 => 1459803892,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5702d6f8472664_43486143 ($_smarty_tpl) {
?>
<div class="jumbotron">
  <h1>Zadkine</h1> 
  <p>We specialize in blablabla</p>
  <form class="form-inline">
    <input type="email" class="form-control" size="50" placeholder="Email Address">
    <button type="button" class="btn btn-danger">Subscribe</button>
  </form>
</div><?php }
}
