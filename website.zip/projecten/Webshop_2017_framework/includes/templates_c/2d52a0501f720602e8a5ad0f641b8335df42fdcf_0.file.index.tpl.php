<?php
/* Smarty version 3.1.29, created on 2016-03-25 17:48:21
  from "C:\wamp\www\Smarty_voorbeeld\templates\index.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_56f56bd56baba5_79728683',
  'file_dependency' => 
  array (
    '2d52a0501f720602e8a5ad0f641b8335df42fdcf' => 
    array (
      0 => 'C:\\wamp\\www\\Smarty_voorbeeld\\templates\\index.tpl',
      1 => 1458924494,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../templates/header.tpl' => 1,
    'file:../templates/footer.tpl' => 1,
  ),
),false)) {
function content_56f56bd56baba5_79728683 ($_smarty_tpl) {
?>
<html>
<head>
<title>Webshop Info</title>
</head>
<body>
    
<!-- <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../templates/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"Info"), 0, false);
?>
 -->

<pre>
<main>
    <section classs="personalinfo">
        
     
    </section>

    <section>
        <div class="produkten">
        </div>
        
        
    </section>
    </main>
    
</main>


<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:../templates/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>



</body>
</html>
<?php }
}
