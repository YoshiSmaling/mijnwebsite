###v1.0.1 (16th June 2016)

- Added code demonstrating how to properly destroy a session as suggested by leebaird. Closes Issue #4

###v1.0.0 (7th January 2016)

- Project uploaded from the latest code by E-Oreo at Developer Shed Forums


###v0.0.3 (9th January 2013)

- Fixed a security bug with the edit account feature that was added on 10/6 - discovered by Stuart Taylor


###v0.0.2 (6th October 2012)

- Expanded the tutorial with new features requested by various people
- Improved password security - suggested by Karl-Uwe Frank


###v0.0.1 (13th March 2012)

- Initial tutorial